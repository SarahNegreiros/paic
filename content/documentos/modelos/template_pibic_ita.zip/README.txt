TEMPLATE RELATÓRIO PIBIC-ITA
==============================

Este template foi desenvolvido com base nas instruções oficiais do ITA para relatórios do PIBIC.

ARQUIVOS INCLUÍDOS:
- main.tex: Arquivo principal do relatório
- capa.tex: Capa do relatório com logos
- assinaturas.tex: Folha de assinaturas
- aprovacao.tex: Formulário de aprovação pelo orientador
- referencias.bib: Arquivo de referências bibliográficas

COMO USAR:
1. Faça upload de todos os arquivos no Overleaf
2. Edite as variáveis no início do arquivo main.tex com suas informações
3. Para adicionar logos:
   - Crie uma pasta "logos/"
   - Adicione os arquivos logo_ita.png e logo_cnpq.png
   - Descomente as linhas dos logos nos arquivos
4. Substitua o texto de exemplo pelo seu conteúdo
5. Compile o projeto

ESPECIFICAÇÕES:
- Formato: A4
- Fonte: Arial (Helvetica), tamanho 12
- Espaçamento: 1,5 linhas
- Máximo: 25 páginas
- Bibliografia: Formato ABNT

Para mais informações, consulte as instruções oficiais do PIBIC-ITA.